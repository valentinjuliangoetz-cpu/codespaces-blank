// Ascendant RPG v6
const STATS=[
 {key:'Vitality', icon:'🩸', color:'#e74c3c', tasks:['Sleep 7–8h','Train / Move','Hydrate + whole foods']},
 {key:'Essence',  icon:'🔥', color:'#ff6bd6', tasks:['Intentional control','Redirect urges','Open posture']},
 {key:'Flow',     icon:'💨', color:'#3ddc84', tasks:['5–10m breathwork','Hourly 3 slow breaths','Calm post-training']},
 {key:'Focus',    icon:'🧠', color:'#5aa7ff', tasks:['Write day focus','<30m scrolling','Deep work block']},
 {key:'Spirit',   icon:'❤️', color:'#f2a365', tasks:['Gratitude','Honest expression','Deep listening']},
 {key:'Faith',    icon:'🕊️', color:'#b695ff', tasks:['5m silence','Purpose-aligned act','Remember your why']},
 {key:'Field',    icon:'🌍', color:'#f7d154', tasks:['Clean space','Sunlight / nature','Positive circle']},
];
const LEVELS=[20,40,60,80], DAYS=30, STORE='ascendant_rpg_v6';

function initState(){
  const raw=localStorage.getItem(STORE); if(raw){try{return JSON.parse(raw)}catch(e){}}
  const s={
    start:new Date().toISOString().slice(0,10),
    days:Array.from({length:DAYS},()=>({})),
    xp:Object.fromEntries(STATS.map(s=>[s.key,0])),
    sleep: {}, // date -> {bed:'22:05', wake:'05:45', hours:7.66}
  };
  localStorage.setItem(STORE, JSON.stringify(s)); return s;
}
let state=initState();

// Helpers
const todayStr=()=> new Date().toISOString().slice(0,10);
const dayIndex=(dstr)=>{ const s=new Date(state.start), d=new Date(dstr); return Math.min(DAYS-1, Math.max(0, Math.floor((d-s)/86400000))); };
const levelFromXP=(xp)=> xp>=LEVELS[3]?5: xp>=LEVELS[2]?4: xp>=LEVELS[1]?3: xp>=LEVELS[0]?2:1;
const pct=(xp)=> Math.min(100, (xp % 20) * 5);
const save=()=> localStorage.setItem(STORE, JSON.stringify(state));

// Time-aware clock
function renderClock(){
  const now=new Date();
  const h=String(now.getHours()).padStart(2,'0'), m=String(now.getMinutes()).padStart(2,'0');
  const greet = now.getHours()<12 ? 'Good morning' : now.getHours()<18 ? 'Good afternoon' : 'Good evening';
  document.getElementById('timeLine').textContent = `${greet} • ${now.toDateString()} • ${h}:${m}`;
}
setInterval(renderClock, 30*1000); renderClock();

// Character SVG (Caucasian male, blue eyes, blonde hair) with emotion & boxer gear toggles
function characterSVG({emotion='neutral', boxer=false, breathing=false}){
  // face tweaks
  const mouth = emotion==='sad' ? 'M 88 78 q 12 -6 24 0' : emotion==='confident' ? 'M 88 82 q 12 6 24 0' : 'M 88 80 q 12 0 24 0';
  const browL = emotion==='confident' ? 'M 80 62 q 8 -4 16 0' : emotion==='sad' ? 'M 80 60 q 8 6 16 0' : 'M 80 61 q 8 0 16 0';
  const browR = emotion==='confident' ? 'M 120 62 q -8 -4 -16 0' : emotion==='sad' ? 'M 120 60 q -8 6 -16 0' : 'M 120 61 q -8 0 -16 0';
  const gloves = boxer ? `<circle cx="55" cy="125" r="12" fill="#e85d75"/><circle cx="145" cy="125" r="12" fill="#e85d75"/>` : '';
  const chestRise = breathing ? 2 : 0;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 240" width="340" height="408">
    <!-- body -->
    <g stroke="#aab" stroke-width="3" fill="none">
      <!-- head -->
      <circle cx="100" cy="60" r="22" fill="#f0d0b0" stroke="#aab"/>
      <!-- hair -->
      <path d="M78,58 q22 -24 44 0 q-6 -18 -22 -18 q-16 0 -22 18" fill="#e7c25a"/>
      <!-- eyes -->
      <circle cx="90" cy="62" r="4" fill="#4aa3ff"/><circle cx="110" cy="62" r="4" fill="#4aa3ff"/>
      <!-- brows -->
      <path d="${browL}" stroke="#6b5830"/><path d="${browR}" stroke="#6b5830"/>
      <!-- mouth -->
      <path d="${mouth}" stroke="#7a3d3d"/>
      <!-- torso -->
      <path d="M78,92 L122,92 L132,138 L120,178 L80,178 L68,138 Z" fill="#1a1d26"/>
      <!-- chest breathing -->
      <ellipse cx="100" cy="${112-chestRise}" rx="${20+chestRise}" ry="${10+chestRise}" fill="#2a2d36" stroke="none" opacity="0.6"/>
      <!-- arms -->
      <path d="M80,102 L58,126 L62,146" />
      <path d="M120,102 L142,126 L138,146" />
      <!-- legs -->
      <path d="M92,178 L88,220" /><path d="M108,178 L112,220" />
      ${gloves}
    </g>
  </svg>`;
}

// Aura canvas per-stat glow
function drawAura(){
  const c=document.getElementById('auraCanvas'); const ctx=c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height);
  // intensity from today's checks (0..3) scaled
  const di=dayIndex(todayStr());
  const totals = STATS.map(s=>{
    const day=state.days[di]||{};
    let n=0; s.tasks.forEach((_,i)=>{ if(day[`${s.key}_${i}`]) n++; });
    return {color:s.color, n};
  });
  // draw soft circles behind char
  totals.forEach((t,idx)=>{
    if(t.n<=0) return;
    const grd=ctx.createRadialGradient(180,170,10,180,170,120+idx*6);
    grd.addColorStop(0, hexToRgba(t.color, 0.20 * Math.min(1, t.n/3)));
    grd.addColorStop(1, hexToRgba(t.color, 0));
    ctx.fillStyle=grd;
    ctx.beginPath(); ctx.arc(180,170,140+idx*6,0,Math.PI*2); ctx.fill();
  });
}
function hexToRgba(hex, a){
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if(!m) return `rgba(255,255,255,${a})`;
  return `rgba(${parseInt(m[1],16)},${parseInt(m[2],16)},${parseInt(m[3],16)},${a})`;
}

// Sleep tracker
function timeToMinutes(t){ if(!t) return null; const [h,m]=t.split(':').map(Number); return h*60+m; }
function durationFromBedWake(bed, wake){
  if(bed==null || wake==null) return null;
  // crosses midnight allowed
  let d = wake - bed; if(d<0) d += 24*60; return d/60;
}
function saveSleepToday(){
  const bed=document.getElementById('bedTime').value||null;
  const wake=document.getElementById('wakeTime').value||null;
  const hrs = durationFromBedWake(timeToMinutes(bed), timeToMinutes(wake));
  const d=todayStr(); state.sleep[d]={bed,wake,hours:hrs}; save();
  // auto-check Vitality sleep task if between 7 and 9 hrs
  const di=dayIndex(d); const key='Vitality_0';
  if(hrs && hrs>=7 && hrs<=9){
    const was=!!(state.days[di]?.[key]);
    state.days[di]=state.days[di]||{};
    state.days[di][key]=true;
    if(!was) state.xp['Vitality']=(state.xp['Vitality']||0)+1;
  }
  render(); // re-render to update stats/XP
}
function renderSleep(){
  const d=todayStr(); const s=state.sleep[d]||{};
  if(s.bed) document.getElementById('bedTime').value=s.bed;
  if(s.wake) document.getElementById('wakeTime').value=s.wake;
  const hrs = s.hours;
  document.getElementById('sleepResult').textContent = hrs? `Today: ${hrs.toFixed(2)} h` : '—';
  // last 7 days avg
  let total=0,count=0;
  for(let i=0;i<7;i++){
    const dd=new Date(d); dd.setDate(dd.getDate()-i); const k=dd.toISOString().slice(0,10);
    if(state.sleep[k]?.hours){ total+=state.sleep[k].hours; count++; }
  }
  document.getElementById('sleepSummary').textContent = `Last 7 days: ${count? (total/count).toFixed(2)+' h avg' : '—'}`;
}

// Mood & boxer mode
function moodFromToday(){
  const di=dayIndex(todayStr());
  const totalTasks = STATS.reduce((acc,s)=> acc+s.tasks.length, 0);
  const done = Object.values(state.days[di]||{}).filter(Boolean).length;
  const ratio = done/totalTasks;
  if(ratio>=0.7) return 'confident';
  if(ratio<=0.2) return 'sad';
  return 'neutral';
}
function boxerToday(){
  const di=dayIndex(todayStr());
  return !!(state.days[di]?.['Vitality_1']); // 'Train / Move' second task
}

// Render stats & UI
function render(){
  // Levels & XP
  const levels = STATS.map(s=>levelFromXP(state.xp[s.key]||0));
  const avgLevel = Math.floor(levels.reduce((a,b)=>a+b,0)/levels.length)||1;
  const totalXP = Object.values(state.xp).reduce((a,b)=>a+b,0);
  document.getElementById('charLevel').textContent = `Level ${avgLevel} • ${totalXP} XP`;
  const globalPct = Math.min(100, (totalXP % (STATS.length*20)) / (STATS.length*20) * 100);
  document.getElementById('globalXP').style.width = `${globalPct}%`;

  // Character render
  const emotion = moodFromToday();
  const boxer = boxerToday();
  const breathing = true;
  document.getElementById('characterSvg').innerHTML = characterSVG({emotion, boxer, breathing});
  document.getElementById('moodTag').textContent = emotion==='confident' ? '😎 Confident' : emotion==='sad' ? '😟 Sad' : '🙂 Neutral';

  // Aura
  drawAura();

  // Stats
  const stats=document.getElementById('stats'); stats.innerHTML='';
  const di=dayIndex(todayStr());
  STATS.forEach(s=>{
    const xp=state.xp[s.key]||0, lv=levelFromXP(xp);
    const card=document.createElement('div'); card.className='stat card';
    card.innerHTML=`<div class="title"><div><strong>${s.icon} ${s.key}</strong> <span class="badge">Lv ${lv} • ${xp} XP</span></div></div>
      <div class="progress"><div class="fill" style="width:${pct(xp)}%"></div></div>`;
    const tasks=document.createElement('div'); tasks.className='tasks';
    s.tasks.forEach((t,i)=>{
      const id=`${s.key}_${i}`, checked=!!(state.days[di][id]);
      const row=document.createElement('label'); row.className='task';
      row.innerHTML=`<input type="checkbox" ${checked?'checked':''}><span>${t}</span>`;
      row.querySelector('input').addEventListener('change',e=>{
        const was=!!state.days[di][id]; state.days[di][id]=e.target.checked;
        if(e.target.checked && !was) state.xp[s.key]=(state.xp[s.key]||0)+1;
        if(!e.target.checked && was) state.xp[s.key]=Math.max(0,(state.xp[s.key]||0)-1);
        save(); render();
      });
      tasks.appendChild(row);
    });
    card.appendChild(tasks); stats.appendChild(card);
  });

  // 30-day grid
  const grid=document.getElementById('grid'); grid.innerHTML='';
  for(let d=0; d<DAYS; d++){
    const day=state.days[d]||{}; const cell=document.createElement('div'); cell.className='cell';
    if(Object.values(day).some(Boolean)) cell.classList.add('done');
    cell.textContent=d+1; grid.appendChild(cell);
  }

  // Achievements sample
  const ach=document.getElementById('achievements');
  const all2=levels.every(l=>l>=2), any4=levels.some(l=>l>=4);
  ach.innerHTML = `<span class="badge">${all2?'🏆':'🔒'} Balanced II+</span> <span class="badge">${any4?'🏆':'🔒'} Any Lv4</span>`;

  // Sleep render
  renderSleep();

  // Chart
  drawXPChart();
}

// Weekly chart (stacked today preview + gridlines; simple vis)
function drawXPChart(){
  const c=document.getElementById('xpChart'), ctx=c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height); const w=c.width,h=c.height,m=40;
  ctx.strokeStyle='#2b2b35'; ctx.beginPath(); ctx.moveTo(m,10); ctx.lineTo(m,h-30); ctx.lineTo(w-10,h-30); ctx.stroke();
  ctx.fillStyle='#9aa0a6'; ctx.font='12px system-ui';
  for(let y=0;y<=6;y++){ const yy=(h-30)-((h-40)/6)*y; ctx.fillText(String(y),10,yy+4); ctx.strokeStyle='#1b1b23'; ctx.beginPath(); ctx.moveTo(m,yy); ctx.lineTo(w-10,yy); ctx.stroke(); }
  const di=dayIndex(todayStr()); let baseline=h-30;
  STATS.forEach((s,si)=>{
    const day=state.days[di]||{}; const gain=s.tasks.reduce((acc,_,i)=> acc + (day[`${s.key}_${i}`]?1:0), 0);
    const barH=((h-40)/6)*gain; if(gain>0){ ctx.fillStyle=s.color; const x=m + (6*(w-m-20))/6 + 6; ctx.fillRect(x, baseline-barH, (w-m-40)/7*0.8, barH); baseline-=barH; }
  });
}

// Sleep save
document.getElementById('saveSleep').addEventListener('click', saveSleepToday);

// Reset today
document.getElementById('resetToday').addEventListener('click',()=>{
  const di=dayIndex(todayStr()); const day=state.days[di]||{};
  Object.keys(day).forEach(id=>{ if(day[id]){ const k=id.split('_')[0]; state.xp[k]=Math.max(0,(state.xp[k]||0)-1);} });
  state.days[di]={}; save(); render();
});

// Export / Import
document.getElementById('exportBtn').addEventListener('click',()=>{
  const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='ascendant_progress.json'; a.click();
});
document.getElementById('importFile').addEventListener('change',e=>{
  const f=e.target.files[0]; if(!f) return; const r=new FileReader();
  r.onload=()=>{ try{ state=JSON.parse(r.result); save(); render(); }catch(err){ alert('Invalid file.'); } };
  r.readAsText(f);
});
document.getElementById('exportCsvBtn').addEventListener('click',()=>{
  let rows=['date,stat,taskIndex,checked,bed,wake,hours'];
  for(let d=0; d<DAYS; d++){
    const date=new Date(state.start); date.setDate(date.getDate()+d); const dateStr=date.toISOString().slice(0,10);
    const day=state.days[d]||{};
    STATS.forEach(s=> s.tasks.forEach((_,i)=> rows.push(`${dateStr},"${s.key}",${i},${day[`${s.key}_${i}`]?1:0},${state.sleep[dateStr]?.bed||''},${state.sleep[dateStr]?.wake||''},${state.sleep[dateStr]?.hours||''}`)));
  }
  const blob=new Blob([rows.join('\\n')],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='ascendant_progress.csv'; a.click();
});

// Install prompt + SW
let deferredPrompt; window.addEventListener('beforeinstallprompt',e=>{ e.preventDefault(); deferredPrompt=e; const b=document.getElementById('installBtn'); b.hidden=false; b.onclick=async()=>{ b.hidden=true; deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; }; });
if('serviceWorker' in navigator){ navigator.serviceWorker.register('sw.js'); }

// Initial render
render();
